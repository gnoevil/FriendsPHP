
<nav class="navbar navbar-light bg-faded">
            <!-- Brand and toggle get grouped for better mobile display -->
     <ul class="nav navbar-nav">
         <li><a class="nav-item nav-link" href="/friends"><h5>Home</h5></a></li>
         <li><a class="nav-item nav-link"href="/logout"><h5>Logout</h5></a></li>
    </ul>
</nav>
