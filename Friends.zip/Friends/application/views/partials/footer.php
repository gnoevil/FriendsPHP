<!-- jQuery -->
<script src="assets/js/jquery-1.12.1.min.js"></script>
<!-- Bootstrap JavaScript -->
<script src="assets/js/bootstrap.min.js"></script>
<!-- jQuery tablesorter -->
<script src="assets/js/jquery.tablesorter.min.js"></script>

<footer>Designed by: Some Developers</footer>
</body>
</html>
