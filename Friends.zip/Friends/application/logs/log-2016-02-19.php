<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-19 17:43:17 --> Config Class Initialized
INFO - 2016-02-19 17:43:17 --> Hooks Class Initialized
DEBUG - 2016-02-19 17:43:17 --> UTF-8 Support Enabled
INFO - 2016-02-19 17:43:17 --> Utf8 Class Initialized
INFO - 2016-02-19 17:43:17 --> URI Class Initialized
DEBUG - 2016-02-19 17:43:17 --> No URI present. Default controller set.
INFO - 2016-02-19 17:43:17 --> Router Class Initialized
INFO - 2016-02-19 17:43:17 --> Output Class Initialized
INFO - 2016-02-19 17:43:17 --> Security Class Initialized
DEBUG - 2016-02-19 17:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 17:43:17 --> Input Class Initialized
INFO - 2016-02-19 17:43:17 --> Language Class Initialized
ERROR - 2016-02-19 17:43:17 --> 404 Page Not Found: Users/index
INFO - 2016-02-19 17:43:57 --> Config Class Initialized
INFO - 2016-02-19 17:43:57 --> Hooks Class Initialized
DEBUG - 2016-02-19 17:43:57 --> UTF-8 Support Enabled
INFO - 2016-02-19 17:43:57 --> Utf8 Class Initialized
INFO - 2016-02-19 17:43:57 --> URI Class Initialized
DEBUG - 2016-02-19 17:43:57 --> No URI present. Default controller set.
INFO - 2016-02-19 17:43:57 --> Router Class Initialized
INFO - 2016-02-19 17:43:57 --> Output Class Initialized
INFO - 2016-02-19 17:43:57 --> Security Class Initialized
DEBUG - 2016-02-19 17:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 17:43:57 --> Input Class Initialized
INFO - 2016-02-19 17:43:57 --> Language Class Initialized
INFO - 2016-02-19 17:43:57 --> Loader Class Initialized
INFO - 2016-02-19 17:43:57 --> Helper loaded: url_helper
INFO - 2016-02-19 17:43:57 --> Database Driver Class Initialized
INFO - 2016-02-19 17:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-02-19 17:43:57 --> Controller Class Initialized
INFO - 2016-02-19 17:43:57 --> File loaded: /Users/gnoevil/Desktop/PHP/PHP_MVC/CodeIgniter-3.0.4 copy/application/views/partials/header.php
INFO - 2016-02-19 17:43:57 --> File loaded: /Users/gnoevil/Desktop/PHP/PHP_MVC/CodeIgniter-3.0.4 copy/application/views/partials/navigation.php
INFO - 2016-02-19 17:43:57 --> File loaded: /Users/gnoevil/Desktop/PHP/PHP_MVC/CodeIgniter-3.0.4 copy/application/views/Users/index.php
INFO - 2016-02-19 17:43:57 --> Final output sent to browser
DEBUG - 2016-02-19 17:43:57 --> Total execution time: 0.0261
INFO - 2016-02-19 17:44:43 --> Config Class Initialized
INFO - 2016-02-19 17:44:43 --> Hooks Class Initialized
DEBUG - 2016-02-19 17:44:43 --> UTF-8 Support Enabled
INFO - 2016-02-19 17:44:43 --> Utf8 Class Initialized
INFO - 2016-02-19 17:44:43 --> URI Class Initialized
DEBUG - 2016-02-19 17:44:43 --> No URI present. Default controller set.
INFO - 2016-02-19 17:44:43 --> Router Class Initialized
INFO - 2016-02-19 17:44:43 --> Output Class Initialized
INFO - 2016-02-19 17:44:43 --> Security Class Initialized
DEBUG - 2016-02-19 17:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 17:44:43 --> Input Class Initialized
INFO - 2016-02-19 17:44:43 --> Language Class Initialized
INFO - 2016-02-19 17:44:43 --> Loader Class Initialized
INFO - 2016-02-19 17:44:43 --> Helper loaded: url_helper
INFO - 2016-02-19 17:44:43 --> Database Driver Class Initialized
INFO - 2016-02-19 17:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-02-19 17:44:43 --> Controller Class Initialized
INFO - 2016-02-19 17:44:43 --> File loaded: /Users/gnoevil/Desktop/PHP/PHP_MVC/CodeIgniter-3.0.4 copy/application/views/partials/header.php
INFO - 2016-02-19 17:44:43 --> File loaded: /Users/gnoevil/Desktop/PHP/PHP_MVC/CodeIgniter-3.0.4 copy/application/views/partials/navigation.php
INFO - 2016-02-19 17:44:43 --> File loaded: /Users/gnoevil/Desktop/PHP/PHP_MVC/CodeIgniter-3.0.4 copy/application/views/Users/index.php
INFO - 2016-02-19 17:44:43 --> Final output sent to browser
DEBUG - 2016-02-19 17:44:43 --> Total execution time: 0.0218
INFO - 2016-02-19 17:45:55 --> Config Class Initialized
INFO - 2016-02-19 17:45:55 --> Hooks Class Initialized
DEBUG - 2016-02-19 17:45:55 --> UTF-8 Support Enabled
INFO - 2016-02-19 17:45:55 --> Utf8 Class Initialized
INFO - 2016-02-19 17:45:55 --> URI Class Initialized
ERROR - 2016-02-19 17:45:55 --> Severity: error --> Exception: syntax error, unexpected '$route' (T_VARIABLE) /Users/gnoevil/Desktop/PHP/PHP_MVC/CodeIgniter-3.0.4 copy/application/config/routes.php 57
INFO - 2016-02-19 17:50:17 --> Config Class Initialized
INFO - 2016-02-19 17:50:17 --> Hooks Class Initialized
DEBUG - 2016-02-19 17:50:17 --> UTF-8 Support Enabled
INFO - 2016-02-19 17:50:17 --> Utf8 Class Initialized
INFO - 2016-02-19 17:50:17 --> URI Class Initialized
DEBUG - 2016-02-19 17:50:17 --> No URI present. Default controller set.
INFO - 2016-02-19 17:50:17 --> Router Class Initialized
INFO - 2016-02-19 17:50:17 --> Output Class Initialized
INFO - 2016-02-19 17:50:17 --> Security Class Initialized
DEBUG - 2016-02-19 17:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 17:50:17 --> Input Class Initialized
INFO - 2016-02-19 17:50:17 --> Language Class Initialized
INFO - 2016-02-19 17:50:17 --> Loader Class Initialized
INFO - 2016-02-19 17:50:17 --> Helper loaded: url_helper
INFO - 2016-02-19 17:50:17 --> Database Driver Class Initialized
INFO - 2016-02-19 17:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-02-19 17:50:17 --> Controller Class Initialized
INFO - 2016-02-19 17:50:17 --> File loaded: /Users/gnoevil/Desktop/PHP/PHP_MVC/CodeIgniter-3.0.4 copy/application/views/partials/header.php
INFO - 2016-02-19 17:50:17 --> File loaded: /Users/gnoevil/Desktop/PHP/PHP_MVC/CodeIgniter-3.0.4 copy/application/views/partials/navigation.php
INFO - 2016-02-19 17:50:17 --> File loaded: /Users/gnoevil/Desktop/PHP/PHP_MVC/CodeIgniter-3.0.4 copy/application/views/Users/index.php
INFO - 2016-02-19 17:50:17 --> Final output sent to browser
DEBUG - 2016-02-19 17:50:17 --> Total execution time: 0.0228
